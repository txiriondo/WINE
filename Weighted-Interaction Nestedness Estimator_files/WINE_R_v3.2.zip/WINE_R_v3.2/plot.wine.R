plot.wine <- function(x,...){
          require(fields)
          w <- t(x$dij.w)
          dim1 <- dim(w)[1]
          dim2 <- dim(w)[2]
          image.plot(x=1:dim1, y=1:dim2, z=w[,dim2:1], 
            main="Weighted distances matrix",xlab="Column",ylab="Row",yaxt="n",...)
          ticks_y<-axTicks(2)
          abline(v=0)
          axis(2, at= ticks_y, labels=rev(ticks_y), las=2) 
}

