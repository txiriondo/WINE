#include "nrutil.h"
#include <stdio.h>
#define NRANSI
#define SWAP(a,b) itemp=(a);(a)=(b);(b)=itemp;
#define M 7
#define NSTACK 10000


void indexx_c(unsigned long n, float arr[], unsigned long indx[]);
