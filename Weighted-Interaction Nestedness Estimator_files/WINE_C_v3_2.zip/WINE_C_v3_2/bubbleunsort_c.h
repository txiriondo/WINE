#include <stdio.h>
#include <stdlib.h>
#include "ran2_c.h"

#define REPEAT  100


void bubbleunsort_c(unsigned int a[],unsigned long n);
