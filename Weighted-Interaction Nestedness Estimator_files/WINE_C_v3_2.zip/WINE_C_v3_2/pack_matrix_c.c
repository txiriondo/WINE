#include "pack_matrix_c.h"

void pack_matrix(unsigned int *a_ij[], unsigned int index_columns[], unsigned int index_rows[], unsigned int n_columns, unsigned int n_rows, unsigned long sum_visits){

 unsigned int i,j;
 unsigned int links_column[n_columns], links_row[n_rows];
 unsigned int visits_column[n_columns],visits_row[n_rows]; 

  for(i=0;i<n_columns;i++){
     links_column[i]=0;
     visits_column[i]=0;
  }
  for(j=0;j<n_rows;j++){
     links_row[j]=0;
     visits_row[j]=0;
  }


  for(i=0;i<n_columns;i++){
    for(j=0;j<n_rows;j++){
//	printf("visits[%u][%u]=%lu\n",j,i,*(visits[j]+i));
	links_column[i]+=a_ij[j][i]>0?1:0;
	visits_column[i]+=a_ij[j][i];
    }
//    printf("column:%u; n.links=%u, n.visits=%lu \n", i, links_column[i],visits_column[i]);
  }

  sort_columns(index_columns, links_column, visits_column, n_columns, sum_visits);


  for(j=0;j<n_rows;j++){
     for(i=0;i<n_columns;i++){
//	printf("packed_columns[%u][%u]=%lu\n",j,i,*(packed_columns[j]+i));
	links_row[j]+=a_ij[j][index_columns[i]]>0?1:0;
	visits_row[j]+=a_ij[j][index_columns[i]];
     }
//     printf("row:%u; n.links=%u, n.visits=%lu\n", j, links_row[j],visits_row[j]);
  }

  sort_rows(index_rows, links_row, visits_row, n_rows, sum_visits);

//   for(j=0;j<n_rows;j++){
//	printf("index_rows[%u]=%u\n",j,index_rows[j]);
//   }

}
