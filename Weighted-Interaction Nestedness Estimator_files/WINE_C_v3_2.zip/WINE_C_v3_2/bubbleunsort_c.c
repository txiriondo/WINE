#include "bubbleunsort_c.h"


void bubbleunsort_c(unsigned int a[],unsigned long n){

unsigned long  i, j;
unsigned long  t;
unsigned int   r;

long     seed=-65525;

//printf("Start bubbleunsort\n");

  for(r=0;r<REPEAT*n;r++){
    i=(unsigned long)(n*ran2_c(&seed));
    j=(unsigned long)(n*ran2_c(&seed));
    if(i!=j){
	  t = a[j];
	  a[j] = a[i];
	  a[i] = t;
    }
  }
//for(i=0;i<n;i++) printf("a[%lu]=%lu\n",i,a[i]);
} 
