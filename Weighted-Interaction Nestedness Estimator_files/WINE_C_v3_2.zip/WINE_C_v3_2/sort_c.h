#include <stdio.h>
#include <stdlib.h>
#include "indexx_c.h"

void sort_columns(unsigned int index_columns[], unsigned int links_column[], unsigned int visits_column[], unsigned int n_columns, unsigned long sum_visits);

void sort_rows(unsigned int index_rows[], unsigned int links_row[], unsigned int visits_row[], unsigned int n_rows, unsigned long sum_visits);
