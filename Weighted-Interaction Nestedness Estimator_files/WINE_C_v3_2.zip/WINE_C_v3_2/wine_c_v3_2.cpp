 /***
Weight-Interaction Nestedness Estimator
12/11/08

Makefile version: 08/01/2009
WINE version: 28/04/2009
***/

#include "pack_matrix_c.h"
#include "bubbleunsort_c.h"
#include "indexx_c.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <string.h>
#include <malloc.h>
#include <algorithm>


#define SAY(A)    fputs((A),stderr)     /** Define del help **/

using namespace std;
typedef   unsigned int  Type_indice;

unsigned int  n_rows=10,n_columns=10;
unsigned long n_realizations=1;
char        filename[40],file_out[40];


void help(){

  fprintf(stderr, "Use: [-h][-f filename] [-r number of rows] [-c number of columns] [-n number of random realizations]\n");
  SAY("In the same order!!!\n");
  SAY("-h 		--- help\n");

  exit(1);

}



void lee_parametros(int argc, char *argv[]){
while(--argc>0 && (*++argv)[0] == '-' ){
  char c= *++argv[0];
  switch(c){
    case 'h':
      help();
      break;
    case 'f':
      sscanf(argv[1],"%s",filename);
      printf("Filename: %s\n",filename);
      argv++;
      break;
    case 'r':
      sscanf(argv[1],"%d",&n_rows);
      printf("N. rows=%d\n",n_rows);
      ++argv;
      break;
    case 'c':
      sscanf(argv[1],"%d",&n_columns);
      printf("N. columns=%d\n",n_columns);
      ++argv;
      break;
    case 'n':
      sscanf(argv[1],"%lu",&n_realizations);
      printf("N. realizations=%lu\n",n_realizations);
      //++argv;
      break;
    default:
      printf("ilegal option\n");
      help();
      break;
    }
  }
}

/*********************************************************************/

int main(int argc, char *argv[]){

unsigned int    i,j;
unsigned long 	r,n;
FILE        	*fp1;

lee_parametros(argc,argv);

//unsigned int visits[n_rows][n_columns], packed[n_rows][n_columns];


unsigned int  index_rows[n_rows],index_columns[n_columns]; 
unsigned long visits_column[n_columns],visits_row[n_rows]; 

unsigned int  *visits[n_rows], *visits_rnd[n_rows],*max_packed[n_rows], *a_ij[n_rows];
double   *prob_col[n_rows], *prob_row[n_rows];
double	 *dw_ij[n_rows], *d_rnd_ij[n_rows], *d_pack_ij[n_rows],d_rnd_r[n_realizations];

unsigned int   v[n_rows*n_columns],vector_sorted[n_rows*n_columns];
float		vector_visits[(n_rows*n_columns)+1];

unsigned long   index_vector_sorted[(n_rows*n_columns)+1];
double   x_i[n_columns], y_j[n_rows];
double   dw_sum=0., d_rnd_sum=0., d_pack_sum=0., d_rnd_ave=0.,std_rnd=0.,eta=0.,z=0.;

unsigned int  links_column[n_columns],links_row[n_rows];
unsigned int  j_row, i_column;
unsigned long i_vect, i_sorted, n_tot=n_rows*n_columns;
unsigned long sum_visits=0, n_links=0,i_fill=0;

  for(j=0;j<n_rows;j++){
     if ((visits[j] = (unsigned int *) malloc(sizeof(unsigned int)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer VISITS\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((visits_rnd[j] = (unsigned int *) malloc(sizeof(unsigned int)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer VISITS_RND\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((max_packed[j] = (unsigned int *) malloc(sizeof(unsigned int)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer MAX_PACK\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((a_ij[j] = (unsigned int *) malloc(sizeof(unsigned int)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer A_IJ\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((prob_col[j] = (double *) malloc(sizeof(double)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer PROB_COL\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((prob_row[j] = (double *) malloc(sizeof(double)*n_columns)) == NULL)
	{
  	  printf("Not enough memory to allocate buffer PROB_ROW\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((dw_ij[j] = (double *) malloc(sizeof(double)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer DW_IJ\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((d_rnd_ij[j] = (double *) malloc(sizeof(double)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer D_RND_IJ\n");
	  exit(1);  /* terminate program if out of memory */
	}
     if ((d_pack_ij[j] = (double *) malloc(sizeof(double)*n_columns)) == NULL)
	{
	  printf("Not enough memory to allocate buffer D_PACK_IJ\n");
	  exit(1);  /* terminate program if out of memory */
	}
     for(i=0;i<n_columns;i++){
	visits[j][i]=0;
	visits_rnd[j][i]=0;
	max_packed[j][i]=0;
	a_ij[j][i]=0;
	prob_col[j][i]=0.0;
	prob_row[j][i]=0.0;
	dw_ij[j][i]=0.0;
	d_rnd_ij[j][i]=0.0;
	d_pack_ij[j][i]=0.0;
     }
     links_row[j]=0;
     visits_row[j]=0;
     index_rows[j]=j;
  }
  for(i=0;i<n_columns;i++){
	links_column[i]=0;
	visits_column[i]=0;
        index_columns[i]=i;
  }  
  for(i=0;i<n_columns*n_rows;i++){
	vector_visits[i]=0.;
	vector_sorted[i]=0;
  }
  for(r=0;r<n_realizations;r++){
     d_rnd_r[r]=0.;
  }

//  printf("initilized arrays\n");
  if((fp1=fopen(filename,"r"))==NULL){

      printf("Err disco profile\n");
      exit(1);
  }
  sum_visits=0;
//  printf("start reading\n");
  while( !feof(fp1) ){
     for(j=0;j<n_rows;j++){
	for(i=0;i<n_columns;i++){
	  fscanf(fp1, "%d\n",visits[j]+i);
//	  printf("row:%u, column:%u,  visits= %u\n",j,i,visits[j][i]);
	  a_ij[j][i]=visits[j][i];
	  sum_visits+=visits[j][i];
	}
	visits[j][i]='\0';
     }
  };
//  printf("end of file\n");

// pack matrix

  pack_matrix(a_ij, index_columns, index_rows, n_columns, n_rows, sum_visits);

//   for(j=0;j<n_rows;j++){
//	printf("index_rows[%u]=%u\n",j,index_rows[j]);
//   }
//   for(i=0;i<n_columns;i++){
//	printf("index_columns[%u]=%u\n",i,index_columns[i]);
//   }
 

//  printf("Packed Matrix:\n");
  sprintf(file_out,"%s.pack",filename);
  if((fp1=fopen(file_out,"w"))==NULL){

      printf("Err disco profile\n");
      exit(1);
  }

  for(j=0;j<n_rows;j++){
    links_row[j]=0;
    visits_row[j]=0;
    for(i=0;i<n_columns;i++){
	links_row[j]+=(a_ij[index_rows[j]][index_columns[i]]>0)?1:0;
	visits_row[j]+=a_ij[index_rows[j]][index_columns[i]];
//	printf("index_columns[%u]=%u\n",i,index_columns[i]);
//	printf("packed[%u][%u]=%u\n",j,i,a_ij[index_rows[j]][index_columns[i]]);
	fprintf(fp1,"%d ",a_ij[index_rows[j]][index_columns[i]]); //nodes starting in en 1
    }
//	printf("index_rows[j]=%u, visits_row[%u]=%u\n",index_rows[j],j,visits_row[j]);
    fprintf(fp1,"\n");
  }
  fclose(fp1);



  for(i=0;i<n_columns;i++){
    links_column[i]=0;
    visits_column[i]=0;
    for(j=0;j<n_rows;j++){
	links_column[i]+=(a_ij[index_rows[j]][index_columns[i]]>0)?1:0;
	visits_column[i]+=a_ij[index_rows[j]][index_columns[i]];
    }
  }

  for(i=0;i<n_columns;i++){
    for(j=0;j<n_rows;j++){
	prob_col[j][i]=(visits_column[i]!=0)?(double)a_ij[index_rows[j]][index_columns[i]]/(double)visits_column[i]:0.0;
	prob_row[j][i]=(visits_row[j]!=0)?(double)a_ij[index_rows[j]][index_columns[i]]/(double)visits_row[j]:0.0;
    }
  }
  n_links=0;
  for(i=0;i<n_columns;i++){
    x_i[i]=(double)i/(double)n_columns + 0.5/(double)n_columns;
    n_links+=links_column[i];
  }

  for(j=0;j<n_rows;j++){
    y_j[j]=(double)j/(double)n_rows + 0.5/(double)n_rows; 
  }

  dw_sum=0.0;
  for(i=0;i<n_columns;i++){
    for(j=0;j<n_rows;j++){
	dw_ij[j][i]=prob_row[j][i]*x_i[i]+prob_col[j][i]*y_j[j];
	dw_sum+=dw_ij[j][i];
    }
  }
  dw_sum/=n_links;

  sprintf(file_out,"%s.wine",filename);
  if((fp1=fopen(file_out,"w"))==NULL){

      printf("Err disco profile\n");
      exit(1);
  }
  for(j=0;j<n_rows;j++){
    for(i=0;i<n_columns;i++){
	fprintf(fp1,"%f ",dw_ij[j][i]); //nodes starting in en 1
    }
    fprintf(fp1,"\n");
  }
  fclose(fp1);

  printf("Weighted-Interaction Nestedness: %lf\n",dw_sum);

//////////////// MAXIMAL PACKED MATRIX

  n=0;
  for(j=0;j<n_rows;j++){
     for(i=0;i<n_columns;i++){
	v[n]=visits[j][i];
//	printf("v[%lu]=%lu\t",n,v[n]);
	n++;
      }
  }

  for(i_vect=0;i_vect<n_tot;i_vect++){
     vector_visits[i_vect+1]=(float)v[i_vect];
     index_vector_sorted[i_vect+1]=i_vect+1;
  }
  indexx_c(n_columns*n_rows, vector_visits, index_vector_sorted);
  for(i_vect=0;i_vect<n_tot;i_vect++){
     vector_sorted[i_vect]=(int)v[index_vector_sorted[n_tot-i_vect]-1];
//   printf("index_vector_sorted[%ld]=%ld, vector_sorted[%ld]=%u\n",i_vect,index_vector_sorted[n_tot-i_vect],i_vect,vector_sorted[i_vect]);
  }

  for(i_vect=0;i_vect<n_tot;i_vect++){
//	printf("vector_sorted[%u]=%u\n",i_vect,vector_sorted[i_vect]);
  }

  i_fill=n_links;
  j_row=n_rows-1;
  i_column=n_columns-1;
  i_sorted=0;
  
  while(i_fill>0){
     j=j_row;
     i=i_column;
     while( (j>0) && (i_fill>0) ){
	j--;
	max_packed[j][i]=vector_sorted[i_sorted];
//	max_packed[j][i]=1;
	i_fill--;
	i_sorted++;
     }
//	printf("j=%d, i=%d, j_row=%d, i_column=%d, i_fill=%lu\n",j,i,j_row,i_column,i_fill);
     i_column--;
     j=j_row;
     i=i_column;
     while( (i>0) && (i_fill>0) ){
	i--;
	max_packed[j][i]=vector_sorted[i_sorted];
//	max_packed[j][i]=1;
	i_fill--;
	i_sorted++;
     }
//	printf("j=%d, i=%d, j_row=%d, i_column=%d, i_fill=%lu\n",j,i,j_row,i_column,i_fill);
     j_row--;

  }

  for(j=0;j<n_rows;j++){
    visits_row[j]=0;
    for(i=0;i<n_columns;i++){
	visits_row[j]+=max_packed[j][i];
    }
  }
  for(i=0;i<n_columns;i++){
    visits_column[i]=0;
    for(j=0;j<n_rows;j++){
	visits_column[i]+=max_packed[j][i];
    }
  }
  for(i=0;i<n_columns;i++){
    for(j=0;j<n_rows;j++){

	prob_col[j][i]=(visits_column[i]!=0)?(double)max_packed[j][i]/(double)visits_column[i]:0.0;
	prob_row[j][i]=(visits_row[j]!=0)?(double)max_packed[j][i]/(double)visits_row[j]:0.0;
//	printf("visits_column[%u]=%lu, max_packed[j][i]=%u; prob_col[%u][i]=%lf\n",i,visits_column[i],max_packed[j][i],j,prob_col[j][i]);
    }
  }

  d_pack_sum=0.0;
  for(i=0;i<n_columns;i++){
    for(j=0;j<n_rows;j++){
	d_pack_ij[j][i]=prob_row[j][i]*x_i[i]+prob_col[j][i]*y_j[j];
//	printf("d_pack_ij[%u][%u]=%lf \t",j,i,d_pack_ij[j][i]);
	d_pack_sum+=d_pack_ij[j][i];
    }
  }
  d_pack_sum/=n_links;
  printf("Weighted-Interaction Nestedness of maximal packed matrix: %lf\n",d_pack_sum);


//////////////// RANDOM MATRICES
  d_rnd_ave=0.0;
  n=0;
  for(r=0;r<n_realizations;r++){
    bubbleunsort_c(v,(unsigned long)(n_rows)*(unsigned long)n_columns);
//    printf("finish bubbleunsort\n");
    n=0;
    for(i=0;i<n_columns;i++){
      for(j=0;j<n_rows;j++){
	visits_rnd[j][i]=v[n++];
	a_ij[j][i]=visits_rnd[j][i];
//	printf("visits_rnd[%u][%u]=%lu\n",j,i,visits_rnd[j][i]);
      }
    }
    pack_matrix(a_ij, index_columns, index_rows, n_columns, n_rows, sum_visits);

    for(j=0;j<n_rows;j++){
      links_row[j]=0;
      visits_row[j]=0;
      for(i=0;i<n_columns;i++){
	links_row[j]+=(a_ij[index_rows[j]][index_columns[i]]>0)?1:0;
	visits_row[j]+=a_ij[index_rows[j]][index_columns[i]];
//	printf("packed[%u][%u]=%u\n",j,i,packed_columns_rows[j][i]);
      }
    }

    for(i=0;i<n_columns;i++){
      links_column[i]=0;
      visits_column[i]=0;
      for(j=0;j<n_rows;j++){
	links_column[i]+=(a_ij[index_rows[j]][index_columns[i]]>0)?1:0;
	visits_column[i]+=a_ij[index_rows[j]][index_columns[i]];
      }
    }

    for(i=0;i<n_columns;i++){
      for(j=0;j<n_rows;j++){
	prob_col[j][i]=(visits_column[i]!=0)?(double)a_ij[index_rows[j]][index_columns[i]]/(double)visits_column[i]:0.0;
	prob_row[j][i]=(visits_row[j]!=0)?(double)a_ij[index_rows[j]][index_columns[i]]/(double)visits_row[j]:0.0;
      }
    }
    n_links=0;
    for(i=0;i<n_columns;i++){
      x_i[i]=(double)i/(double)n_columns + 0.5/(double)n_columns;
      n_links+=links_column[i];
    }

    for(j=0;j<n_rows;j++){
      y_j[j]=(double)j/(double)n_rows + 0.5/(double)n_rows; 
    }

    d_rnd_sum=0.0;
    for(i=0;i<n_columns;i++){
      for(j=0;j<n_rows;j++){
	d_rnd_ij[j][i]=prob_row[j][i]*x_i[i]+prob_col[j][i]*y_j[j];
	d_rnd_sum+=d_rnd_ij[j][i];
      }
    }
    d_rnd_r[r]=d_rnd_sum/n_links;
    d_rnd_ave+=d_rnd_r[r];
//    printf("Random distance: %lf\n",d_rnd_r[r]);
  }
  d_rnd_ave/=n_realizations;
  std_rnd=0.0;
  for(r=0;r<n_realizations;r++){
    std_rnd+=(d_rnd_r[r]-d_rnd_ave)*(d_rnd_r[r]-d_rnd_ave);
  }
  std_rnd/=(n_realizations-1);
  std_rnd=sqrt(std_rnd);
  printf("Average Random Weighted-Interaction Nestedness: %lf\n",d_rnd_ave);

  z=(dw_sum - d_rnd_ave)/std_rnd;  
  printf("z=%lf\n", z);

  eta=(dw_sum-d_rnd_ave)/(d_pack_sum-d_rnd_ave);

  printf("eta=%lf\n",eta);

}

