#include "sort_c.h"

void sort_columns(unsigned int index_columns[], unsigned int links_column[], unsigned int visits_column[], unsigned int n_columns, unsigned long sum_visits){

unsigned int     i_column;
float		 links_column_fl[n_columns+1];
unsigned long    index_columns_l[n_columns+1];

  for(i_column=0;i_column<n_columns;i_column++){
     links_column_fl[i_column+1]=(float)links_column[i_column]+(double)visits_column[i_column]/(double)sum_visits;
     index_columns_l[i_column+1]=(unsigned long)index_columns[i_column];
  }
  if(n_columns>100-2){
     printf("change define NSTACK 100 in indexx_c.c\n");
     exit(0);
  }
  indexx_c(n_columns, links_column_fl, index_columns_l);
  for(i_column=1;i_column<=n_columns;i_column++){
     index_columns[i_column-1]=(unsigned int)index_columns_l[i_column]-1;
//     printf("index_columns[i_column=%u]=%u, index_columns_l[i_column+1]=%ld\n", i_column-1,index_columns[i_column-1],index_columns_l[i_column]);

  }
}

//////////////////////////////////////////

void sort_rows(unsigned int index_rows[], unsigned int links_row[], unsigned int visits_row[], unsigned int n_rows, unsigned long sum_visits){

unsigned int     j_row;
float		 links_row_fl[n_rows+1];
unsigned long    index_rows_l[n_rows+1];

  for(j_row=0;j_row<n_rows;j_row++){
     links_row_fl[j_row+1]=(float)links_row[j_row]+(double)visits_row[j_row]/(double)sum_visits;
     index_rows_l[j_row+1]=(unsigned long)index_rows[j_row];
//   printf("links_row_fl[%u]=%f, index_rows_l=%ld\n",j_row+1,links_row_fl[j_row+1],index_rows_l[j_row+1]);
  }
  if(n_rows>100-2){
     printf("change define NSTACK 100 in indexx_c.c\n");
     exit(0);
  }
  indexx_c(n_rows, links_row_fl, index_rows_l);
  for(j_row=1;j_row<=n_rows;j_row++){
     index_rows[j_row-1]=(unsigned int)index_rows_l[j_row]-1;
  }
//  for(j_row=0;j_row<n_rows;j_row++){
//     printf("index_rows[j_row=%u]=%u, index_row_l=%ld\n", j_row,index_rows[j_row],index_rows_l[j_row+1]);
//  }

}
