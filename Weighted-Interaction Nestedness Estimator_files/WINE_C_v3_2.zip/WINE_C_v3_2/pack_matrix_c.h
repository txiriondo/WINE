#include <stdio.h>
#include <stdlib.h>
#include "sort_c.h"

void pack_matrix(unsigned int *a_ij[], unsigned int index_columns[], unsigned int index_rows[], unsigned int n_columns, unsigned int n_rows, unsigned long sum_visits);
