function varargout = WINEv3_2(varargin)
% WINEV3_2 M-file for WINEv3_2.fig
%      WINEV3_2, by itself, creates a new WINEV3_2 or raises the existing
%      singleton*.
%
%      H = WINEV3_2 returns the handle to a new WINEV3_2 or the handle to
%      the existing singleton*.
%
%      WINEV3_2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WINEV3_2.M with the given input arguments.
%
%      WINEV3_2('Property','Value',...) creates a new WINEV3_2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before weighted_nestedness_estimator_ave2_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to WINEv3_2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help WINEv3_2

% Last Modified by GUIDE v2.5 22-Apr-2009 15:24:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @WINEv3_2_OpeningFcn, ...
                   'gui_OutputFcn',  @WINEv3_2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
%file='pru.xls'

% --- Executes just before WINEv3_2 is made visible.
function WINEv3_2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to WINEv3_2 (see VARARGIN)


% Choose default command line output for WINEv3_2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes WINEv3_2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = WINEv3_2_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function matrix_Callback(hObject, eventdata, handles)
% hObject    handle to matrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of matrix as text
%        str2double(get(hObject,'String')) returns contents of matrix as a double

%mat=get(handles.matrix,'String');


% --- Executes during object creation, after setting all properties.
function matrix_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function fcell_Callback(hObject, eventdata, handles)
% hObject    handle to fcell (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fcell as text
%        str2double(get(hObject,'String')) returns contents of fcell as a double

%fc=get(handles.fcell,'String');

% --- Executes during object creation, after setting all properties.
function fcell_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fcell (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called





% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lcell_Callback(hObject, eventdata, handles)
% hObject    handle to lcell (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lcell as text
%        str2double(get(hObject,'String')) returns contents of lcell as a double

%lc=get(handles.lcell,'String');

% --- Executes during object creation, after setting all properties.
function lcell_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lcell (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_1_Callback(hObject, eventdata, handles)
% hObject    handle to menu_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Input_file_Callback(hObject, eventdata, handles)
% hObject    handle to Input_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function inputfile_Callback(hObject, eventdata, handles)
% hObject    handle to inputfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

file = uigetfile('*.xls');
set(handles.name_file, 'String', file)

handles.file = file;
guidata(hObject,handles)

% --- Executes on button press in btrun.
function btrun_Callback(hObject, eventdata, handles)
% hObject    handle to btrun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

realiz=100;               % number of iterations to average random matrix
distr_r=0;

Mu = xlsread(handles.file,-1);
Mu=sparse(Mu);

P_mu=Mu>0;
m_mu=size(Mu);


maxi=max(max(Mu));
if maxi(1,1)<2
    maxi(1,1)=2;
end

histo=sum(histc(full(Mu),1:maxi(1,1)),2);


d1_mu=zeros(m_mu(1),m_mu(2));   % preallocating for the speed 
dr1=zeros(m_mu(1),m_mu(2));
dp1=zeros(m_mu(1),m_mu(2));
D1_mu=zeros(m_mu(1),m_mu(2));
DR1=zeros(m_mu(1),m_mu(2));
ER1=zeros(m_mu(1),m_mu(2));
E1_mu=zeros(m_mu(1),m_mu(2));
DP1=zeros(m_mu(1),m_mu(2));
EP1=zeros(m_mu(1),m_mu(2));
xmu_i=zeros(1,m_mu(1));
ymu_j=zeros(1,m_mu(2));
Mu_pack=zeros(m_mu(1),m_mu(2));


%%%%% Completelly Packed Matrix 


Mu_pack=zeros(m_mu(1),m_mu(2));
i_val=nnz(Mu);
val=sort(nonzeros(Mu))
%Mu_pack(m_mu(1),: )=1;
for i=1:m_mu(1)
    Mu_pack(m_mu(1)-i+1,m_mu(2))=val(i_val);
%    Mu_pack(m_mu(1)-i+1,m_mu(2))=1;
    i_val=i_val-1;
end
ultif=m_mu(1);
ultic=m_mu(2)-1;

while(i_val>0)
    for i=1:min(ultic,i_val)
        Mu_pack(ultif,ultic-i+1)=val(i_val);
%       Mu_pack(ultif,ultic-i+1)=1;
       i_val=i_val-1;
    end
    ultif=ultif-1;
    
    if(i_val>0)
        for i=1:min(ultif,i_val)
                Mu_pack(ultif-i+1,ultic)=val(i_val);
%                Mu_pack(ultif-i+1,ultic)=1;
                i_val=i_val-1;
        end
        ultic=ultic-1;   
     end
end
 
%%%%%%%%%%%%%%%%%% PACKING MATRICES
for j=1:m_mu(2)   
    r_mu(j)=nnz(P_mu(:,j));   
end

for j=1:m_mu(1)    
    r1_mu(j)=nnz(P_mu(j,:));
end

[im jm]=sort(r_mu);      
f2_mu=Mu(:,jm);

[im1 jm1]=sort(r1_mu);     
f12_mu=f2_mu(jm1,:);        %packed matrix 

f1_mu=f12_mu>0;             %packed adjacentia matrix

%%%%%%  strength

C1_mu=sum(f12_mu);                   
CC1_mu=(sum(f12_mu,2))';

P1=sum(Mu_pack);                        %%%% MATRIZ cPacked
PC1=(sum(Mu_pack,2))';

for i=1:length(C1_mu)
    if(C1_mu(i)== 0)
        D1_mu(:,i)=f12_mu(:,i).*0;
    else
        D1_mu(:,i)=f12_mu(:,i)./C1_mu(i);
    end
end
    strs1_mu=(sum(D1_mu,2))';
    
for i=1:length(CC1_mu)  
    if(CC1_mu(i)==0)
        E1_mu(i,:)=f12_mu(i,:).*0;
    else
        E1_mu(i,:)=f12_mu(i,:)./CC1_mu(i);
    end
end
    strs2_mu=sum(E1_mu);
    
            
    
for i=1:length(P1)
    if(P1(i)==0)
        DP1(:,i)=Mu_pack(:,i).*0;
    else
        DP1(:,i)=Mu_pack(:,i)./P1(i);
    end    
end
    
    
for i=1:length(PC1) 
    if(PC1(i)==0)
        EP1(i,:)=Mu_pack(i,:).*0;
    else
        EP1(i,:)=Mu_pack(i,:)./PC1(i);
    end
end
   


%%% Random Matrix
for r=1:realiz
    Mu_vect=reshape(Mu,m_mu(1)*m_mu(2),1);
    indic_perm=randperm(m_mu(1)*m_mu(2))';
    Mu_vect_perm=Mu_vect(indic_perm);
    Mu_perm=reshape(Mu_vect_perm,m_mu(1),m_mu(2));
    B=sparse(Mu_perm);
    AR=B>0;
%%%%%%%%%%%%%%%%%% PACKING MATRICES
    for j=1:m_mu(2)   
        r_f(j)=nnz(AR(:,j));
    end

    for j=1:m_mu(1)    
        r_c(j)=nnz(AR(j,:));
    end

    [kk ll]=sort(r_f);         %%%% RANDOM MATRIX
    g=AR(:,ll);
    g2=B(:,ll);


    [kk1 ll1]=sort(r_c);      
    g1=g(ll1,:);
    g12=g2(ll1,:);          %packed random matrix 

    %%%%%% strength

    G1=sum(g12);                        %%%% RANDOM MATRIX 
    GC1=(sum(g12,2))';

    
    for i=1:length(G1)
        if(G1(i)==0)
            DR1(:,i)=g12(:,i).*0;
        else
            DR1(:,i)=g12(:,i)./G1(i);
        end    
    end
    strr1=(sum(DR1,2))';
    
    
    for i=1:length(GC1) 
        if(GC1(i)==0)
            ER1(i,:)=g12(i,:).*0;
        else
            ER1(i,:)=g12(i,:)./GC1(i);
        end
    end
    strr2=sum(ER1);
  


    for i=1:m_mu(1)
        for j=1:m_mu(2)
            xmu_i(i)=(i-1)/m_mu(1)+1/(2*m_mu(1));
            ymu_j(j)=(j-1)/m_mu(2)+1/(2*m_mu(2));
        
            d1_mu(i,j)=D1_mu(i,j)*xmu_i(i)+E1_mu(i,j)*ymu_j(j);
            dr1(i,j)=(DR1(i,j)*xmu_i(i)+ER1(i,j)*ymu_j(j));
            dp1(i,j)=(DP1(i,j)*xmu_i(i)+EP1(i,j)*ymu_j(j));
        end
    end
    distr_r(r)=sum(sum(dr1))/nnz(dr1);

end
dist_mu=sum(sum(d1_mu))/nnz(d1_mu)
distp=sum(sum(dp1))/nnz(dp1)

distr_ave=mean(distr_r)
distr_std=std(distr_r)

eta=(dist_mu-distr_ave)/(distp-distr_ave)
z_score=(dist_mu-distr_ave)/distr_std
x=dist_mu;
if x < distr_ave
    x=distr_ave + (distr_ave-dist_mu)
end
p_value=1.0-abs(normcdf(x,distr_ave,distr_std))

axes(handles.axes1);
%plotedit on
handles.mu = d1_mu;
imagesc(handles.mu), colorbar;
xlabel('Column','FontName','Times');
ylabel('Row','FontName','Times');

maxi=max(max(Mu))
if maxi(1,1)<2
    maxi=2
end

axes(handles.axes2);
hold on
box on
set(handles.axes2,'XMinorTick','on')
xlabel('N.events','FontName','Times');
ylabel('N.links','FontName','Times');

handles.histo = histo;
loglog(handles.histo,'r*')
axis([1 20 1 maxi(1,1)])

histor=sum(histc(full(Mu_perm),1:maxi(1,1),2));
handles.histor = histor;
loglog(handles.histor,'b+')
%axis([1 20 1 maxi])
grid on
hold off


set(handles.mostra, 'String', num2str(dist_mu,'%.3f'))
set(handles.mostrar, 'String', num2str(distr_ave,'%.3f'))
set(handles.text_z, 'String', num2str(z_score,'%.2f'))
set(handles.text_p, 'String', (num2str(p_value,'%.3f')))
set(handles.mostraeta, 'String', num2str(eta,'%.2f'))



% --------------------------------------------------------------------
function help_menu_Callback(hObject, eventdata, handles)
% hObject    handle to help_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function help_using_menu_Callback(hObject, eventdata, handles)
% hObject    handle to help_using_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function Help_About_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Help_About_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

HelpPath = which('wine_help.html');
web(HelpPath);

% --------------------------------------------------------------------
function Help_Using_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Help_Using_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

HelpPath = which('using_help.html');
web(HelpPath);



% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes during object creation, after setting all properties.
function mostraeta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mostraeta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);


